#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>

#include "message.h"
#include "socket.h"
#include "blackjack.h" 

int playerHand[6];

int computerHand[6];

int playerIndex;

int computerIndex;

void editCard(int cardValue, int playerArr[]) {

    FILE* filePtr;
    int fileSize;

    // open correct file regarding the suite
    filePtr = fopen("playingCards/playerHand.txt", "r");
    if (filePtr == NULL) {
        perror("Error opening file");
    }

    // Obtain the file size
    fseek(filePtr, 0L, SEEK_END);
    fileSize = ftell(filePtr);
    rewind(filePtr);

    char buffer[fileSize+1];

    // load file into memory
    for (int i = 0; i < fileSize; i++) {
        char fileChar = fgetc(filePtr);
        buffer[i] = fileChar;
    } // for

    // change the value of the card in accordance to the value parameter
    int j = 0;
    while (j < fileSize) {
      if (playerArr == 1 && buffer[j] == '!') {
        buffer[j] = cardValue;
      }
      else if (playerArr == 2 && buffer[j] == '@') {
        buffer[j] = cardValue;
      }
      else if (playerArr == 3 && buffer[j] == '#') {
        buffer[j] = cardValue;
      }
      else if (playerArr == 4 && buffer[j] == '$') {
        buffer[j] = cardValue;
      }
      else if (playerArr == 4 && buffer[j] == '&') {
        buffer[j] = cardValue;
      } 
      j++;
    } // while

    // prints out the card 
    for (int k = 0; k < fileSize; k++) {
            printf("%c", buffer[k]); 
        } //for
}

void updateBoard() {
    
    // replace with struct variable that keeps track of player total
    int playerTotal = 0;
    // print the dealers hand
    printf("\n                                              DEALER TOTAL: %d\n\n", playerTotal);
    editCard(53, computerHand);
    printf("\n\n");
    // print the players hand
    printf("\n                                              PLAYER TOTAL : %d\n\n", playerTotal);
    editCard(52, playerHand); 
    printf("\n\n");
}

//connects to server
//is dealt two cards from the server
//is sent a message telling top card of dealer
//sends hit or stayy to server (0 or 1?)
//after stay, messages sent from computer about what card it picks up
//highest score under 21 wins



/*
Takes in the message from the server and converts it into two strings to be passed
to the function that will draw the cards with ascii
*/
int playerTotal = 0;
int computerTotal = 0;

void receive_card(bool player, char* card)
{
  int cardInt = atoi(card);
  card_t drawnCard;
  drawnCard.digit = index_to_digit(cardInt);
  drawnCard.suit = index_to_suit(cardInt);
  char suitStr[20];
  char digitStr[20];
  //convert the int to a string for the ascii art
  sprintf(suitStr, "%d", drawnCard.suit);
  sprintf(digitStr, "%d", drawnCard.digit);

  //save value into gobal array
  if (player) {
    playerIndex++;
    playerHand[playerIndex] = cardInt;
  }
  else {
    computerIndex++;
    computerHand[computerIndex] = cardInt;
  }

  //printf("%d \n", index_to_digit(cardInt));
  //editCard(suitStr, digitStr);
}

/*
Receives a message from the server
*/
char* client_receive(bool player, int socket_fd)
{ 
    if (player) {
      char * card = receive_message(socket_fd);
      if (card == NULL) {
        perror("Failed to read card from server");
        exit(EXIT_FAILURE);
      } 
      int temp = atoi(card);
      playerTotal += temp;
      return card;
    } else {
      char * card = receive_message(socket_fd);
      if (card == NULL) {
        perror("Failed to read card from server");
        exit(EXIT_FAILURE);
      } 
      int temp = atoi(card);
      computerTotal += temp;
      return card;
    }
      
}

char* client_receive_both(bool player, int socket_fd)
{ 
   if (player) {
    char * card = receive_message(socket_fd);
      if (card == NULL) {
        perror("Failed to read card from server");
        exit(EXIT_FAILURE);
      } 
      int temp = atoi(card);
      playerTotal += temp;
      char * m = receive_message(socket_fd);
      printf("Total = %s \n", m);
    // print the received total
      return card;
   } 
   else {
    char * card = receive_message(socket_fd);
      if (card == NULL) {
        perror("Failed to read card from server");
        exit(EXIT_FAILURE);
      } 
      int temp = atoi(card);
      computerTotal += temp;
      char * m = receive_message(socket_fd);
      printf("Total = %s \n", m);
    // print the received total
      return card;
   }
}

int play(int socket_fd) {

// Receive the computer cards (sent first) //Read a message from the server
    char* first = client_receive(false, socket_fd);
    printf("first message: %s\n", first);
    char* second = client_receive(false, socket_fd);
    printf("second message: %s\n", second);
    char* third = client_receive(false, socket_fd);
    printf("third message: %s\n", third);
    char* fourth = client_receive(false, socket_fd);
    printf("fourth message: %s\n", fourth);

    receive_card(false, (client_receive(false, socket_fd)));
    
    receive_card(false, (client_receive(false, socket_fd)));
    
    receive_card(true, (client_receive(true, socket_fd)));
    
    receive_card(true, (client_receive_both(true, socket_fd)));
    
    printf("playtotal = %d \n", playerTotal);
    printf("comptotal = %d \n", computerTotal);
    while(playerTotal <= 30){
      printf("playtotal = %d \n", playerTotal);
      printf("comptotal = %d \n", computerTotal);
      // receive an initial "hit or stay" message from the comp
      char* m = client_receive(true, socket_fd);
      printf("%s\n", m);

      // read in client's choice
      char * userinput;
      size_t n;
      getline(&userinput,&n,stdin);
      //If the user wants another card
      if (strcmp(userinput, "Hit\n") == 0) {
        //Send over whether the user wants to hit or stay to the server
        int rc = send_message(socket_fd, userinput);
        if (rc == -1) {
        perror("Failed to send 'Hit' to server");
        exit(EXIT_FAILURE);
      }


      
      // and then we want to receive a card from server
      //char* m = client_receive(socket_fd);
      //printf("%s", m);
       // and then we want to receive a card from server and display in ascii

      char* update = client_receive(false, socket_fd);
      printf("Update_Hand branch print: %s \n", update);
      receive_card(true, (client_receive_both(true, socket_fd)));

      //receives send from update hand
      
      //free(card);

      continue; 
    }
    //If the user is done
    else if (strcmp(userinput, "Stay\n") == 0) {
      //printf("Got to stay part of client");
      //Tell the server we are staying
      int rc = send_message(socket_fd, userinput);
      if (rc == -1) {
        perror("Failed to send 'STAY' to server");
        exit(EXIT_FAILURE);
      }

      // char* final = client_receive(socket_fd);
      // printf("%s", final);
      break;
    }
    else {
      //printf("invalid input \n");
      int rc = send_message(socket_fd, userinput);
      if (rc == -1) {
        perror("Failed to send invalid input to server");
        exit(EXIT_FAILURE);
      }
      continue;
    }
    //  * Draw card -> strcmp(userinput, "draw\n") == 0
    //  * Stay (relinquish control) -> strcmp(userinput, "stay\n") == 0
    //  * total card count ( this might just be kept track of by server)
    //  * 
    //  */

   
  /*
    if(strcmp(final, "You Won! :)") == 0){
        break; // change this to updating count of wins +1
    } else if (strcmp(final, "You have lost this game\n") == 0){
        break; // change this to updating loss count +1
    }
    */

    
    // The message received from the server will be:
    /**
     * Card drawn (update your hand)
     * Card drawn by others
     *      Update the displ
y to include a new card image     * Whether you've won or lost
     * 
     */

    // Free the message
    //free(message);
    
  } // while  
  
  while ((playerTotal < 30) && (computerTotal < 30) && (computerTotal < playerTotal)) {
    char* update = client_receive(false, socket_fd);
      printf("Update_Hand branch print: %s \n", update);
      //receive_card(client_receive_both(false, socket_fd));
    printf("comptotal = %d \n", computerTotal);
  }
  
  // typing "Stay" brings you out the while loop, now you're waiting for the computer/server to play their turn
   //Read a message from the server
    printf("Trying to read final message \n");
    char* final = client_receive(false, socket_fd);
      printf("%s\n", final);


  // Close socket
  //close(socket_fd);

  return 0;
}

int main(int argc, char** argv) {
  if (argc != 3) {
    fprintf(stderr, "Usage: %s <server name> <port>\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  // Read command line arguments
  char* server_name = argv[1];
  unsigned short port = atoi(argv[2]);

  // Connect to the server
  int socket_fd = socket_connect(server_name, port);
  if (socket_fd == -1) {
    perror("Failed to connect");
    exit(EXIT_FAILURE);
  }
  
  play(socket_fd);
  //close(socket_fd);
  return 0;
}